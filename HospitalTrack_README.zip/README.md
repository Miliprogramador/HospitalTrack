<div align="center">

# HospitalTrack V2

### Intelligent Medical Equipment Tracking System

**FPGA-based inventory control · Embedded systems · Hardware/software integration**

![Version](https://img.shields.io/badge/Version-2.0-087F8C?style=flat-square)
![FPGA](https://img.shields.io/badge/FPGA-Intel%20MAX%2010-0071C5?style=flat-square)
![Board](https://img.shields.io/badge/Board-DE10--Lite-263746?style=flat-square)
![ESP32](https://img.shields.io/badge/ESP32-Arduino-CB3434?style=flat-square)
![HDL](https://img.shields.io/badge/HDL-Verilog-087F8C?style=flat-square)
![UART](https://img.shields.io/badge/UART-115200%20bps-263746?style=flat-square)

**Universidad de las Américas Puebla (UDLAP)**  
Embedded Systems Laboratory · Final Project · 2026

[Overview](#project-overview) · [Architecture](#system-architecture) · [Memory](#fpga-memory-architecture) · [Protocol](#uart-communication-protocol) · [Validation](#experimental-validation) · [Setup](#installation-and-operation) · [Downloads](#repository-and-downloads)

<img src="assets/diagrams/system-architecture.png" alt="HospitalTrack system architecture" width="950">

</div>

---

## Project overview

HospitalTrack is an embedded inventory management system designed to register, locate and transfer medical equipment between hospital departments. It addresses the difficulty of maintaining an accurate record of equipment locations in a shared clinical environment.

The project combines an **Intel MAX 10 FPGA on a Terasic DE10-Lite board** with an **ESP32 development module**. The ESP32 provides a serial-console interface, while the FPGA implements the inventory memory, command validation, location updates, equipment counting and physical feedback. This separation makes the FPGA the authoritative source of equipment locations rather than using it solely as a display peripheral.

The system is a laboratory implementation of manually registered equipment movements. It does not use RFID, GPS or automatic physical-location sensing.

### Technical highlights

| **50** equipment records | **8** hospital zones | **200 bits** of location memory | **50 MHz** FPGA clock |
| :---: | :---: | :---: | :---: |
| 6 seven-segment displays | 10 status/zone LEDs | 115200 baud UART | 5 Verilog design modules |

### Main capabilities

- Locate any equipment record using its decimal ID.
- Register and transfer equipment between eight hospital zones.
- Browse a paginated inventory and equipment catalog, with search by ID or name.
- List equipment in a selected zone and display hospital-wide totals.
- Validate binary requests and reject invalid commands without changing inventory.
- Present operation results on the FPGA's seven-segment displays and LEDs.
- Reset the location memory to a known initial state using `KEY0`.

## System architecture

The architecture separates the user interface, communication layer and hardware control logic.

| Layer | Implementation | Responsibility |
| --- | --- | --- |
| User interface | PC / Arduino Serial Monitor | Enter commands and view human-readable results. |
| Communication gateway | ESP32 / Arduino C++ | Menu, catalog, request encoding, response validation and UART transport. |
| Hardware controller | DE10-Lite / Verilog | Inventory storage, validation, updates, queries and counting. |
| Physical feedback | HEX0–HEX5 and LEDR0–LEDR9 | Show equipment ID, zone, count and operation status. |

The computer communicates with the ESP32 over USB serial. The ESP32 exchanges binary request and response frames with the FPGA over a separate UART link. The FPGA processes each request and returns its result; the ESP32 translates the result into equipment and zone names.

### FPGA block diagram

<div align="center">
<img src="assets/diagrams/fpga-block-diagram.png" alt="FPGA module hierarchy and signal flow" width="950">
</div>

| Module | Hardware function |
| --- | --- |
| [`uart_rx.v`](src/rtl/uart_rx.v) | Synchronizes and samples the serial input; reconstructs an 8-bit byte and pulses `valid`. |
| [`uart_tx.v`](src/rtl/uart_tx.v) | Serializes each byte using UART 8N1 framing; exposes `busy` and `done`. |
| [`hospitaltrack_core.v`](src/rtl/hospitaltrack_core.v) | Parses requests, validates fields, stores locations, counts records and generates 48-bit responses. |
| [`hospitaltrack_top.v`](src/rtl/hospitaltrack_top.v) | Connects RX, CORE and TX; sequences the six response bytes. |
| [`HospitalTrack_DE10_Lite.v`](src/rtl/HospitalTrack_DE10_Lite.v) | Board-level top entity: clock, reset synchronization, decimal display decoding and LED mapping. |
| [`HospitalTrack_ESP32.ino`](src/HospitalTrack_ESP32/HospitalTrack_ESP32.ino) | User interface, equipment catalog, UART protocol and response handling. |

## Hardware implementation

<div align="center">
<img src="assets/diagrams/hardware-connections.png" alt="ESP32 and DE10-Lite UART wiring" width="950">
</div>

### Required hardware and tools

| Hardware | Development environment |
| --- | --- |
| Terasic DE10-Lite (MAX 10 FPGA) | Intel Quartus Prime Lite |
| ESP32 Dev Module | Arduino IDE with ESP32 board support |
| USB cables and jumper wires | Active-HDL for Verilog simulation |
| Computer with USB ports | Arduino Serial Monitor |

### UART wiring

| ESP32 | DE10-Lite JP1 | FPGA pin | Direction |
| --- | --- | --- | --- |
| GPIO17 / TX2 | GPIO0, physical pin 1 | `PIN_V10` | ESP32 → FPGA |
| GPIO16 / RX2 | GPIO1, physical pin 2 | `PIN_W10` | FPGA → ESP32 |
| GND | GND, physical pin 12 | — | Common reference |

The FPGA uses `MAX10_CLK1_50` (`PIN_P11`) as its 50 MHz clock and `KEY[0]` (`PIN_B8`) as the active-low manual reset input. Full board assignments are provided in [`Pin_Planner.qsf`](src/constraints/Pin_Planner.qsf) and [`Pin_Planner.csv`](src/constraints/Pin_Planner.csv).

> [!IMPORTANT]
> Power both boards through their respective USB connections. Use 3.3 V UART logic and a common ground. Cross TX and RX, and do not connect 5 V to either UART input. The wiring table describes the intended configuration; the photographs alone do not establish every electrical connection.

## FPGA memory architecture

<div align="center">
<img src="assets/diagrams/memory-architecture.png" alt="50 by 4 bit FPGA inventory memory" width="950">
</div>

The CORE implements a register array with 50 independently addressable entries:

```verilog
reg [3:0] inventory [0:49];
```

Each entry stores the current zone of one equipment record. The address is calculated as `asset_id - 1`, so equipment IDs 01–50 map to addresses 0–49. Four bits are required to represent nine possible values (unregistered plus eight hospital zones).

**Logical memory capacity: 50 × 4 = 200 bits (25 bytes).** This is the location-storage capacity, not the total FPGA resource utilization. The design does not claim that the array is mapped to dedicated M9K block RAM.

| Zone | Binary | Department | LED |
| :---: | :---: | --- | :---: |
| 00 | `0000` | Unregistered | — |
| 01 | `0001` | Storage | LEDR0 |
| 02 | `0010` | Emergency | LEDR1 |
| 03 | `0011` | Operating room | LEDR2 |
| 04 | `0100` | Intensive care (ICU) | LEDR3 |
| 05 | `0101` | Inpatient care | LEDR4 |
| 06 | `0110` | Imaging | LEDR5 |
| 07 | `0111` | Laboratory | LEDR6 |
| 08 | `1000` | Outpatient consultation | LEDR7 |

### Read, write and count operations

- **Write:** a valid MOVE request updates only `inventory[asset_id-1]`.
- **Read:** a QUERY request retrieves the stored zone without modifying the record.
- **Overwrite:** moving an already registered asset replaces its previous location; it does not create a duplicate record.
- **Count:** the CORE scans one entry per clock cycle and counts matches in the selected zone. At 50 MHz, the 50-entry scan takes 50 cycles (1 µs), excluding request reception and response generation.
- **Reset:** the active-low reset clears all 50 entries to zone 00. Locations are volatile and are not retained after power loss or reconfiguration.

The ESP32 stores equipment names and zone labels; it obtains the current locations from the FPGA rather than maintaining a separate authoritative inventory.

## Finite state machines

The design uses sequential control logic to coordinate serial communication and inventory operations. The following descriptions correspond to the V2 Verilog implementation.

| Controller | State sequence |
| --- | --- |
| UART RX | `S_IDLE → S_START → S_DATA → S_STOP` |
| UART TX | `S_IDLE → S_START → S_DATA → S_STOP` |
| Inventory CORE | `RECEIVE → SCAN → REPLY` |
| TOP response sequencer | `WAIT_RESPONSE → SEND_BYTE → WAIT_TX_DONE` |
| Board reset synchronizer | `00 → 01 → 11` (equivalent state representation) |

### Inventory CORE FSM

```mermaid
stateDiagram-v2
    direction LR
    [*] --> RECEIVE: Reset
    RECEIVE --> RECEIVE: Collect request bytes / timeout recovery
    RECEIVE --> SCAN: Valid request / write if MOVE
    RECEIVE --> REPLY: Invalid request
    SCAN --> SCAN: Scan index 0 through 48
    SCAN --> REPLY: Scan index 49
    REPLY --> RECEIVE: Generate frame and pulse response_valid
```

`RECEIVE` collects the five bytes using `rx_index` and validates the request. `SCAN` counts matching entries after a valid operation. `REPLY` assembles the six-byte response and updates the physical feedback when appropriate. An invalid request bypasses the scan and does not write to memory.

### TOP response sequencer

<div align="center">
<img src="assets/diagrams/top-fsm.png" alt="Three-state response transmission controller" width="900">
</div>

The TOP latches the 48-bit response, selects one byte at a time and waits for the UART transmitter's `done` signal before advancing the byte counter. The ESP32 waits for a response before issuing another request.

<details>
<summary><strong>UART state behavior and board reset</strong></summary>

- RX detects a low start bit, verifies it near its midpoint, samples eight data bits and accepts the byte when the stop bit is valid.
- TX generates the start bit, eight data bits (LSB first) and the stop bit; `done` signals completion.
- The board wrapper combines power-on reset and `KEY0`. A two-bit synchronizer releases reset after two clock edges. Its reset diagram is an equivalent representation, not a separately declared FSM.

<img src="assets/diagrams/reset-sequence.png" alt="Board reset synchronization sequence" width="850">

</details>

The individual state-machine images uploaded to the repository root complement these descriptions.

## UART communication protocol

| Parameter | Value |
| --- | --- |
| Baud rate | 115200 bps |
| Format | 8N1 (8 data bits, no parity, 1 stop bit) |
| Bit order | Least significant bit first within each UART byte |
| FPGA timing | 434 clock cycles per bit (approximately 8.68 µs) |
| Request | 5 bytes / 40 data bits |
| Response | 6 bytes / 48 data bits |
| Integrity check | Bytewise XOR checksum |
| Timeouts | FPGA partial-request timeout: 20 ms; ESP32 response timeout: 700 ms |

### Binary frame format

```text
REQUEST  (5 bytes)
+--------+--------+--------+---------+----------+
|  0xA5  |   ID   |  ZONE  | COMMAND | CHECKSUM |
+--------+--------+--------+---------+----------+

RESPONSE (6 bytes)
+--------+--------+--------+--------+--------+----------+
|  0x5A  |   ID   |  ZONE  | STATUS | COUNT  | CHECKSUM |
+--------+--------+--------+--------+--------+----------+
```

The checksum is the XOR of every preceding byte in the frame. It detects some transmission errors, but is not cryptographic authentication and does not detect every possible corruption.

| Command (hex) | Operation | ID | Zone field |
| :---: | --- | --- | --- |
| `01` | MOVE | 1–50 | 1–8 |
| `02` | QUERY | 1–50 | 0 |
| `03` | COUNT | 0 | 0–8 |
| `04` | QUIET_QUERY | 1–50 | 0 |
| `05` | QUIET_COUNT | 0 | 0–8 |

Quiet commands preserve the previous physical display on success, allowing the ESP32 to browse inventory without continuously changing the board's output.

| Status (hex) | Meaning |
| :---: | --- |
| `00` | Movement accepted |
| `01` | Query successful |
| `02` | Count successful |
| `E1` | Invalid equipment ID |
| `E2` | Invalid zone |
| `E3` | Invalid command |
| `E4` | Invalid checksum |

### Example transaction

Assuming Emergency is initially empty, register equipment 07 in zone 02:

```text
Serial command: MOVER 07 02
MOVE request:   A5 07 02 01 A1
FPGA response:  5A 07 02 00 01 5E
Board display:  07 02 01
```

The hexadecimal frame shown is the MOVE transaction itself. The ESP32 also performs a quiet query to obtain the previous location before sending MOVE.

## User interface and physical feedback

<table>
<tr><td width="50%" align="center"><strong>Serial console</strong></td><td width="50%" align="center"><strong>Working hardware</strong></td></tr>
<tr><td><img src="assets/serial/main-menu.png" alt="HospitalTrack serial main menu" width="100%"></td><td><img src="assets/photos/IMG_8666.jpeg" alt="ESP32 and DE10-Lite connected with the display active" width="100%"></td></tr>
</table>

The console provides seven menu options: locate equipment, transfer equipment, browse inventory, list by zone, browse catalog, view hospital summary and help. The firmware interface is in Spanish; the repository documentation is in English.

### Seven-segment display format

| HEX5–HEX4 | HEX3–HEX2 | HEX1–HEX0 |
| :---: | :---: | :---: |
| Equipment ID | Zone | Number of equipment records in that zone |
| `07` | `02` | `01` |

The six digits are decimal. `LEDR0–LEDR7` indicate the selected registered zone, `LEDR8` indicates a successful displayed operation and `LEDR9` indicates a rejection reported by the FPGA. Zone 00 turns off the zone LEDs. An invalid FPGA request preserves the previous numeric display while changing the status indicators.

## Experimental validation

The evidence combines RTL inspection, memory simulation and real hardware operation. Each method verifies a different aspect of the implementation.

### 1. RTL hardware structure

The Quartus RTL schematic documents the synthesized design's logical structure at the RTL-viewer level: reset logic, top-level integration, seven-segment decoding and LED control. It is not a post-fit resource or timing report.

- [Original Quartus RTL schematic (PDF)](RTL_Hospitaltrack.pdf)
- [Annotated RTL implementation evidence (PDF)](evidence/HospitalTrack%20RTL%20Implementation%20Evidence.pdf)
- [High-resolution RTL schematic (PNG)](assets/diagrams/rtl-schematic.png)

### 2. Memory waveform validation

<div align="center">
<img src="Waveforms%20Hospital_track.jpeg" alt="Active-HDL simulation waveforms for FPGA inventory memory" width="100%">
</div>

The Active-HDL testbench [`tb_hospitaltrack_memoria.v`](src/sim/tb_hospitaltrack_memoria.v) injects bytes directly into the CORE, observes the real internal array through hierarchical references and checks the entire 50-entry memory after each scenario. The `mem_we`, `mem_re`, `mem_addr`, `mem_wdata` and `mem_rdata` signals are simulation probes, not physical FPGA ports.

| Phase | Testbench operation | Expected memory/result |
| :---: | --- | --- |
| 1 | Move equipment 02 to zone 04 | Address 01 stores 4; zone count = 1 |
| 2 | Move equipment 50 to zone 04 | Address 49 stores 4; zone count = 2 |
| 3 | Query equipment 02 | Zone 04; count = 2 |
| 4 | Move equipment 02 to zone 08 | Address 01 changes to 8; zone count = 1 |
| 5 | Query equipment 50 | Zone 04 retained; count = 1 |
| 6 | Send corrupted MOVE checksum | Status `E4`; no memory write |
| 7 | Query equipment 50 again | Zone 04 retained after rejection |
| 8 | Count equipment in zone 04 | Count = 1 |
| 9 | Assert reset | All 50 entries return to 0 |
| 10 (`A`) | Query equipment 02 | Zone 00; unregistered count = 50 (`0x32`) |

The supplied simulation reaches completion phase `B`. The captured counters show **9 response checks, 3 accepted writes and 4 queries**. Phase 9 is a reset, not a request; the rejected MOVE is not counted as a write. The testbench also checks that all other entries remain unchanged during these operations.

A second testbench, [`tb_hospitaltrack_v2.v`](src/sim/tb_hospitaltrack_v2.v), is provided for bit-level UART, full-capacity inventory and display/reset testing. Its inclusion does not by itself establish that all of its tests were executed successfully.

### 3. Functional validation — serial console

<table>
<tr><td width="50%"><strong>Initial query: equipment 07 unregistered</strong></td><td width="50%"><strong>Successful transfer to Emergency</strong></td></tr>
<tr><td><img src="assets/serial/initial-query.png" alt="Equipment 07 initially unregistered"></td><td><img src="assets/serial/successful-transfer.png" alt="Successful movement of equipment 07 to Emergency"></td></tr>
<tr><td><strong>Inventory reflects the stored location</strong></td><td><strong>Zone query returns equipment 07</strong></td></tr>
<tr><td><img src="assets/serial/inventory.png" alt="Inventory lists equipment 07 in Emergency"></td><td><img src="assets/serial/zone-query.png" alt="Emergency zone contains one equipment record"></td></tr>
</table>

The serial evidence documents a successful registration of equipment 07 (electrocardiograph) in Emergency, followed by consistent inventory and zone-query results.

### 4. Physical hardware validation

<table>
<tr><td width="50%" align="center"><strong>07 · 02 · 01</strong></td><td width="50%" align="center"><strong>15 · 01 · 04</strong></td></tr>
<tr><td><img src="assets/photos/IMG_8667.jpeg" alt="FPGA display 070201 and LEDs 8 and 1 active"></td><td><img src="assets/photos/IMG_8668.jpeg" alt="FPGA display 150104 and LEDs 8 and 0 active"></td></tr>
<tr><td>Equipment 07, Emergency, one registered record in the zone.</td><td>Equipment 15, Storage, four registered records in the zone.</td></tr>
</table>

The illuminated displays and zone/status LEDs are consistent with the documented serial results. These photographs establish the observed board outputs, rather than an exhaustive physical test of every equipment ID.

### 5. Final observed inventory snapshot

<div align="center">
<img src="assets/serial/hospital-summary.png" alt="Hospital summary with five registered and forty-five unregistered records" width="700">
</div>

| Location | Records | Share of capacity |
| --- | ---: | ---: |
| Storage | 4 | 8% |
| Emergency | 1 | 2% |
| Other registered zones | 0 | 0% |
| Unregistered | 45 | 90% |
| **Total** | **50** | **100%** |

The snapshot contains five registered records and 45 unregistered records. It represents the observed demonstration state, not a deployment in an actual hospital.

**Evidence documents:** [Functional Validation Evidence (PDF)](evidence/HospitalTrack%20Functional%20Validation%20Evidence.pdf) · [Hardware Integration Evidence (PDF)](evidence/HospitalTrack%20Hardware%20Integration%20Evidence.pdf)

## Installation and operation

### Step 1 — Configure the FPGA

1. Create a Quartus project for the MAX 10 device on the DE10-Lite board.
2. Add the five Verilog files from [`src/rtl`](src/rtl/). Set `HospitalTrack_DE10_Lite` as the top-level entity.
3. Merge the provided [`Pin_Planner.qsf`](src/constraints/Pin_Planner.qsf) assignments into the project QSF. The supplied file is a pin-assignment fragment, not a complete Quartus project.
4. Compile the design and program the board with the generated `.sof` using the Quartus Programmer and USB-Blaster.

Do not add the simulation testbenches to the synthesis file set.

### Step 2 — Program the ESP32

1. Open [`HospitalTrack_ESP32.ino`](src/HospitalTrack_ESP32/HospitalTrack_ESP32.ino) in Arduino IDE.
2. Install ESP32 board support, select **ESP32 Dev Module** and select the board's actual COM port.
3. Upload the sketch. Open Serial Monitor at **115200 baud**, with the line ending set to **Newline** (`Nueva línea`).
4. Connect both boards according to the UART wiring table. Use the menu or the direct commands below.

### Step 3 — Run a basic demonstration

Starting with cleared inventory, enter each command from the main menu. Press Enter to return to the menu when prompted.

```text
CONSULTAR 07
MOVER 07 02
CONSULTAR 07
```

Expected behavior: the initial query returns zone 00; the MOVE registers the record in Emergency; the final query returns zone 02. With no other records in Emergency, the board displays `07 02 01`, with LEDR1 and LEDR8 illuminated. Use menu option 4 to verify the zone list and option 6 to inspect the hospital summary.

### Step 4 — Reproduce the memory simulation

1. Create a Verilog simulation design in Active-HDL and compile `hospitaltrack_core.v` and `tb_hospitaltrack_memoria.v`.
2. Select `tb_hospitaltrack_memoria` as the simulation top and initialize the simulation.
3. Add `phase`, `rst_n`, `mem_we`, `mem_re`, `mem_addr`, `mem_wdata`, `mem_rdata`, `mem_equipo02`, `mem_equipo50`, `response_valid`, `resp_status` and `resp_count` to the waveform window.
4. Run until the testbench finishes (a 25,000 ns global timeout is included). Inspect the write, read, overwrite, error-rejection and reset phases. Use hexadecimal radix for comparison with the supplied waveform, or decimal for equipment counts.
5. Check the console for the testbench's `ALL MEMORY CHECKS PASSED` message and the expected counters.

For the full UART testbench, compile all five RTL modules and `tb_hospitaltrack_v2.v`, then select `tb_hospitaltrack_v2` as the simulation top. It has a longer timeout because it transmits real UART bit sequences.

## Repository and downloads

```text
.
├── README.md
├── assets/                 # Diagrams, hardware photos and console captures
├── evidence/               # Directly viewable technical evidence PDFs
├── src/
│   ├── rtl/                # Five synthesizable Verilog modules
│   ├── sim/                # Memory and UART testbenches
│   ├── constraints/        # Quartus pin assignments and pin table
│   └── HospitalTrack_ESP32/ # Arduino sketch
├── Hospital_track_codigos.zip
├── HospitalTrack_Diagrams_System.zip
├── Hospitaltrack_evidence_1.zip
├── Hospitaltrack_evidence_2.zip
├── RTL_Hospitaltrack.pdf
└── Waveforms Hospital_track.jpeg
```

The root also contains the five individual state-machine diagram images. The original archives are retained for convenient offline access.

| Download | Contents |
| --- | --- |
| [Source code package](Hospital_track_codigos.zip) | RTL, ESP32 sketch, simulation testbenches and pin assignments. |
| [System diagrams package](HospitalTrack_Diagrams_System.zip) | System, hardware, FPGA block and memory architecture diagrams (PNG/SVG). |
| [Evidence package — Part 1](Hospitaltrack_evidence_1.zip) | Technical PDFs, RTL, waveform, photos, console captures and one demonstration video. |
| [Evidence package — Part 2](Hospitaltrack_evidence_2.zip) | Two additional demonstration videos. |

The two evidence archives are independent ZIP files; extract each separately. Together they contain the three original demonstration videos.

## Scope and future development

HospitalTrack V2 demonstrates manual equipment-location registration using FPGA-controlled volatile memory and a wired serial interface. The current implementation does not automatically detect physical equipment movement, preserve inventory after power loss, or provide a networked multi-user clinical application. The XOR checksum is a basic integrity check, not a security mechanism.

Future extensions could include nonvolatile storage, RFID or other identification technologies, a networked interface, user authentication and a larger inventory. These are proposed improvements, not implemented features of V2.

## Project team

| Developer | Institution |
| --- | --- |
| **Diego Garrido Jauckens** | Universidad de las Américas Puebla |
| **Sergio Emilio López Montalvo** | Universidad de las Américas Puebla |

**Course:** Embedded Systems Laboratory  
**Project:** HospitalTrack V2 — Intelligent Medical Equipment Tracking System  
**Year:** 2026

---

<div align="center">

**HospitalTrack V2**  
*From serial commands to verified FPGA memory and physical feedback.*

Academic engineering project · UDLAP

</div>
