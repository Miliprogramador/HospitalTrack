// UART transmitter, 8N1, LSB first, idle HIGH.
module uart_tx #(
    parameter integer CLOCK_HZ = 50000000,
    parameter integer BAUD_RATE = 115200
)(
    input  wire       clk,
    input  wire       rst_n,
    input  wire       start,
    input  wire [7:0] data,
    output reg        tx,
    output wire       busy,
    output reg        done
);
    localparam integer TICKS = (CLOCK_HZ + BAUD_RATE / 2) / BAUD_RATE;
    localparam [1:0] S_IDLE=2'd0, S_START=2'd1, S_DATA=2'd2, S_STOP=2'd3;
    reg [1:0] state;
    reg [15:0] timer;
    reg [2:0] bit_number;
    reg [7:0] shift;
    assign busy = (state != S_IDLE);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tx <= 1'b1;
            state <= S_IDLE;
            timer <= 16'd0;
            bit_number <= 3'd0;
            shift <= 8'd0;
            done <= 1'b0;
        end else begin
            done <= 1'b0;
            case (state)
                S_IDLE: begin
                    tx <= 1'b1;
                    if (start) begin
                        shift <= data;
                        bit_number <= 3'd0;
                        tx <= 1'b0;
                        timer <= TICKS-1;
                        state <= S_START;
                    end
                end
                S_START: begin
                    if (timer == 0) begin
                        tx <= shift[0];
                        timer <= TICKS-1;
                        state <= S_DATA;
                    end else timer <= timer-1'b1;
                end
                S_DATA: begin
                    if (timer == 0) begin
                        if (bit_number == 3'd7) begin
                            tx <= 1'b1;
                            timer <= TICKS-1;
                            state <= S_STOP;
                        end else begin
                            bit_number <= bit_number+1'b1;
                            tx <= shift[bit_number+1'b1];
                            timer <= TICKS-1;
                        end
                    end else timer <= timer-1'b1;
                end
                S_STOP: begin
                    if (timer == 0) begin
                        done <= 1'b1;
                        state <= S_IDLE;
                        tx <= 1'b1;
                    end else timer <= timer-1'b1;
                end
                default: state <= S_IDLE;
            endcase
        end
    end
endmodule
