// UART receiver, 8N1, LSB first, asynchronous active-low reset.
module uart_rx #(
    parameter integer CLOCK_HZ = 50000000,
    parameter integer BAUD_RATE = 115200
)(
    input  wire       clk,
    input  wire       rst_n,
    input  wire       rx,
    output reg  [7:0] data,
    output reg        valid
);
    localparam integer TICKS = (CLOCK_HZ + BAUD_RATE / 2) / BAUD_RATE;
    localparam [1:0] S_IDLE=2'd0, S_START=2'd1, S_DATA=2'd2, S_STOP=2'd3;
    reg [1:0]  state;
    reg [15:0] timer;
    reg [2:0]  bit_number;
    reg [7:0]  shift;
    reg rx_meta, rx_sync;

    // Synchronize the incoming asynchronous UART RX signal.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rx_meta <= 1'b1;
            rx_sync <= 1'b1;
        end else begin
            rx_meta <= rx;
            rx_sync <= rx_meta;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= S_IDLE;
            timer <= 16'd0;
            bit_number <= 3'd0;
            shift <= 8'd0;
            data <= 8'd0;
            valid <= 1'b0;
        end else begin
            valid <= 1'b0;
            case (state)
                S_IDLE: begin
                    if (!rx_sync) begin
                        timer <= (TICKS/2)-1;
                        state <= S_START;
                    end
                end
                S_START: begin
                    if (timer == 0) begin
                        if (!rx_sync) begin
                            timer <= TICKS-1;
                            bit_number <= 3'd0;
                            state <= S_DATA;
                        end else begin
                            state <= S_IDLE;
                        end
                    end else timer <= timer-1'b1;
                end
                S_DATA: begin
                    if (timer == 0) begin
                        shift[bit_number] <= rx_sync;
                        timer <= TICKS-1;
                        if (bit_number == 3'd7) state <= S_STOP;
                        else bit_number <= bit_number+1'b1;
                    end else timer <= timer-1'b1;
                end
                S_STOP: begin
                    if (timer == 0) begin
                        if (rx_sync) begin
                            data <= shift;
                            valid <= 1'b1;
                        end
                        state <= S_IDLE;
                    end else timer <= timer-1'b1;
                end
                default: state <= S_IDLE;
            endcase
        end
    end
endmodule
