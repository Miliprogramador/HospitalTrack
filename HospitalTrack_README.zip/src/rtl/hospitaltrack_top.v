// Integra UART (sin cambios) y controlador de inventario V2.
module hospitaltrack_top #(
    parameter integer CLOCK_HZ=50000000,
    parameter integer BAUD_RATE=115200
)(
    input wire clk, rst_n, uart_rx_pin,
    output wire uart_tx_pin,
    output wire [7:0] display_id, display_zone, display_count,
    output wire display_ok, display_error
);
    wire [7:0] incoming_byte;
    wire incoming_valid, response_valid, tx_busy, tx_done;
    wire [47:0] response;
    reg tx_start;
    reg [7:0] tx_data;
    reg [47:0] outbound;
    reg [2:0] byte_num;
    reg [1:0] send_state;
    uart_rx #(.CLOCK_HZ(CLOCK_HZ),.BAUD_RATE(BAUD_RATE)) receiver (
        .clk(clk),.rst_n(rst_n),.rx(uart_rx_pin),
        .data(incoming_byte),.valid(incoming_valid));
    hospitaltrack_core #(.CLOCK_HZ(CLOCK_HZ)) inventory (
        .clk(clk),.rst_n(rst_n),.rx_data(incoming_byte),.rx_valid(incoming_valid),
        .response_frame(response),.response_valid(response_valid),
        .display_id(display_id),.display_zone(display_zone),.display_count(display_count),
        .display_ok(display_ok),.display_error(display_error));
    uart_tx #(.CLOCK_HZ(CLOCK_HZ),.BAUD_RATE(BAUD_RATE)) transmitter (
        .clk(clk),.rst_n(rst_n),.start(tx_start),.data(tx_data),
        .tx(uart_tx_pin),.busy(tx_busy),.done(tx_done));
    // Una solicitud a la vez: ESP32 espera respuesta antes de enviar otra.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tx_start <= 0; tx_data <= 0; outbound <= 0;
            byte_num <= 0; send_state <= 0;
        end else begin
            tx_start <= 0;
            case (send_state)
                0: if (response_valid) begin
                    outbound <= response; byte_num <= 0; send_state <= 1;
                end
                1: if (!tx_busy) begin
                    case (byte_num)
                        0: tx_data <= outbound[47:40];
                        1: tx_data <= outbound[39:32];
                        2: tx_data <= outbound[31:24];
                        3: tx_data <= outbound[23:16];
                        4: tx_data <= outbound[15:8];
                        default: tx_data <= outbound[7:0];
                    endcase
                    tx_start <= 1; send_state <= 2;
                end
                2: if (tx_done) begin
                    if (byte_num == 5) send_state <= 0;
                    else begin byte_num <= byte_num+1'b1; send_state <= 1; end
                end
                default: send_state <= 0;
            endcase
        end
    end
endmodule
