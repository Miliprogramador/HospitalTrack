// Top-Level Entity: HospitalTrack_DE10_Lite
// DE10-Lite: LED activos en 1; displays activos en 0, DP siempre apagado.
module HospitalTrack_DE10_Lite(
    input wire MAX10_CLK1_50,
    input wire [1:0] KEY,
    input wire ESP_RX_FROM_ESP32_TX,
    output wire ESP_TX_TO_ESP32_RX,
    output wire [9:0] LEDR,
    output wire [7:0] HEX0, HEX1, HEX2, HEX3, HEX4, HEX5
);
    wire clk = MAX10_CLK1_50;
    // Reset al configurar la FPGA y al presionar KEY0. Liberacion sincronizada.
    reg [3:0] por = 0;
    always @(posedge clk) if (por != 15) por <= por+1'b1;
    wire raw_reset_n = KEY[0] & (&por);
    reg [1:0] reset_pipe = 0;
    always @(posedge clk or negedge raw_reset_n) begin
        if (!raw_reset_n) reset_pipe <= 0;
        else reset_pipe <= {reset_pipe[0],1'b1};
    end
    wire rst_n = reset_pipe[1];
    wire [7:0] id, zone, amount;
    wire ok, err;
    hospitaltrack_top #(.CLOCK_HZ(50000000),.BAUD_RATE(115200)) system (
        .clk(clk),.rst_n(rst_n),.uart_rx_pin(ESP_RX_FROM_ESP32_TX),
        .uart_tx_pin(ESP_TX_TO_ESP32_RX),
        .display_id(id),.display_zone(zone),.display_count(amount),
        .display_ok(ok),.display_error(err));
    assign LEDR[7:0] = (zone>=1 && zone<=8) ? (8'b1 << (zone-1)) : 8'b0;
    assign LEDR[8] = ok;
    assign LEDR[9] = err;
    function [7:0] digit;
        input [7:0] n;
        begin
            case (n)
                0: digit=8'hC0; 1: digit=8'hF9; 2: digit=8'hA4;
                3: digit=8'hB0; 4: digit=8'h99; 5: digit=8'h92;
                6: digit=8'h82; 7: digit=8'hF8; 8: digit=8'h80;
                9: digit=8'h90; default: digit=8'hFF;
            endcase
        end
    endfunction
    // Valores en decimal, no hexadecimal. Rango maximo: 50.
    assign HEX5 = digit(id/8'd10);
    assign HEX4 = digit(id%8'd10);
    assign HEX3 = digit(zone/8'd10);
    assign HEX2 = digit(zone%8'd10);
    assign HEX1 = digit(amount/8'd10);
    assign HEX0 = digit(amount%8'd10);
endmodule
