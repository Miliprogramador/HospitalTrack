// HospitalTrack V2 - 50 equipos, 8 zonas, sin switches.
// Solicitud: A5 ID ZONA CMD XOR. Respuesta: 5A ID ZONA STATUS CANT XOR.
module hospitaltrack_core #(
    parameter integer CLOCK_HZ = 50000000
)(
    input wire clk, rst_n,
    input wire [7:0] rx_data,
    input wire rx_valid,
    output reg [47:0] response_frame,
    output reg response_valid,
    output reg [7:0] display_id, display_zone, display_count,
    output reg display_ok, display_error
);
    localparam [7:0] MOVE=8'h01, QUERY=8'h02, COUNT=8'h03,
                     QUIET_QUERY=8'h04, QUIET_COUNT=8'h05;
    localparam [7:0] MOVED=8'h00, QUERIED=8'h01, COUNTED=8'h02,
                     BAD_ID=8'hE1, BAD_ZONE=8'hE2,
                     BAD_CMD=8'hE3, BAD_XOR=8'hE4;
    localparam integer RX_TIMEOUT = CLOCK_HZ/50;
    localparam [1:0] RECEIVE=0, SCAN=1, REPLY=2;
    reg [1:0] state;
    reg [3:0] inventory [0:49];
    reg [2:0] rx_index;
    reg [7:0] asset_id, requested_zone, command;
    reg [31:0] gap_timer;
    reg [5:0] scan_index;
    reg [7:0] status, returned_zone, count;
    reg [7:0] next_status, next_zone;
    wire valid_id = asset_id >= 1 && asset_id <= 50;
    wire is_move = command == MOVE;
    wire is_query = command == QUERY || command == QUIET_QUERY;
    wire is_count = command == COUNT || command == QUIET_COUNT;
    wire quiet = command == QUIET_QUERY || command == QUIET_COUNT;
    integer k;

    always @* begin
        next_status = MOVED;
        next_zone = 0;
        if (rx_data != (8'hA5 ^ asset_id ^ requested_zone ^ command))
            next_status = BAD_XOR;
        else if (!is_move && !is_query && !is_count)
            next_status = BAD_CMD;
        else if ((is_count && asset_id != 0) || (!is_count && !valid_id))
            next_status = BAD_ID;
        else if ((is_move && (requested_zone < 1 || requested_zone > 8)) ||
                 (is_query && requested_zone != 0) ||
                 (is_count && requested_zone > 8))
            next_status = BAD_ZONE;
        else if (is_move) begin
            next_status = MOVED; next_zone = requested_zone;
        end else if (is_query) begin
            next_status = QUERIED;
            next_zone = {4'b0, inventory[asset_id-1]};
        end else begin
            next_status = COUNTED; next_zone = requested_zone;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (k=0; k<50; k=k+1) inventory[k] <= 0;
            state <= RECEIVE; rx_index <= 0; gap_timer <= 0;
            asset_id <= 0; requested_zone <= 0; command <= 0;
            status <= 0; returned_zone <= 0; count <= 0; scan_index <= 0;
            response_frame <= 0; response_valid <= 0;
            display_id <= 0; display_zone <= 0; display_count <= 0;
            display_ok <= 0; display_error <= 0;
        end else begin
            response_valid <= 0;
            case (state)
                RECEIVE: begin
                    if (rx_valid) begin
                        gap_timer <= 0;
                        case (rx_index)
                            0: if (rx_data == 8'hA5) rx_index <= 1;
                            1: begin asset_id <= rx_data; rx_index <= 2; end
                            2: begin requested_zone <= rx_data; rx_index <= 3; end
                            3: begin command <= rx_data; rx_index <= 4; end
                            4: begin
                                rx_index <= 0;
                                status <= next_status;
                                returned_zone <= next_zone;
                                count <= 0; scan_index <= 0;
                                if (next_status[7]) state <= REPLY;
                                else begin
                                    if (is_move)
                                        inventory[asset_id-1] <= requested_zone[3:0];
                                    state <= SCAN;
                                end
                            end
                            default: rx_index <= 0;
                        endcase
                    end else if (rx_index != 0) begin
                        if (gap_timer >= RX_TIMEOUT-1) begin
                            rx_index <= 0; gap_timer <= 0;
                        end else gap_timer <= gap_timer + 1'b1;
                    end else gap_timer <= 0;
                end
                SCAN: begin
                    // Uno por ciclo: evita una cadena de 50 sumadores.
                    if ({4'b0,inventory[scan_index]} == returned_zone)
                        count <= count + 1'b1;
                    if (scan_index == 49) state <= REPLY;
                    else scan_index <= scan_index + 1'b1;
                end
                REPLY: begin
                    response_frame <= {8'h5A,asset_id,returned_zone,status,count,
                         (8'h5A ^ asset_id ^ returned_zone ^ status ^ count)};
                    response_valid <= 1;
                    if (status[7]) begin
                        display_ok <= 0; display_error <= 1;
                    end else if (!quiet) begin
                        display_id <= asset_id; display_zone <= returned_zone;
                        display_count <= count; display_ok <= 1; display_error <= 0;
                    end
                    state <= RECEIVE;
                end
                default: begin state <= RECEIVE; rx_index <= 0; end
            endcase
        end
    end
endmodule
