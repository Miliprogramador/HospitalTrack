`timescale 1ns/1ps
// Banco de pruebas de la tarjeta completa: UART real, 50 registros y displays.
module tb_hospitaltrack_v2;
    reg clk=0;
    always #10 clk=~clk;
    reg [1:0] key=2'b11;
    reg rx=1;
    wire tx;
    wire [9:0] led;
    wire [7:0] h0,h1,h2,h3,h4,h5;
    HospitalTrack_DE10_Lite dut (.MAX10_CLK1_50(clk),.KEY(key),
        .ESP_RX_FROM_ESP32_TX(rx),.ESP_TX_TO_ESP32_RX(tx),.LEDR(led),
        .HEX0(h0),.HEX1(h1),.HEX2(h2),.HEX3(h3),.HEX4(h4),.HEX5(h5));
    localparam integer BIT_NS=8680;
    integer tests=0, i;
    reg [7:0] a,b,c,d,e,f;
    task fail;
        input [8*100-1:0] reason;
        begin $display("FAIL: %0s at %0t",reason,$time); $finish; end
    endtask
    task send_byte;
        input [7:0] data;
        integer j;
        begin
            rx=0; #(BIT_NS);
            for(j=0;j<8;j=j+1) begin rx=data[j]; #(BIT_NS); end
            rx=1; #(BIT_NS);
        end
    endtask
    task read_byte;
        output [7:0] data;
        integer j;
        begin
            @(negedge tx); #(BIT_NS+BIT_NS/2);
            for(j=0;j<8;j=j+1) begin data[j]=tx; #(BIT_NS); end
            if(tx!==1) fail("UART stop bit");
            #(BIT_NS/4);
        end
    endtask
    task request;
        input [7:0] id,zone,cmd,corrupt,expected_zone,expected_status,expected_count;
        begin
            fork
                begin
                    send_byte(8'hA5); send_byte(id); send_byte(zone); send_byte(cmd);
                    send_byte(8'hA5^id^zone^cmd^corrupt);
                end
                begin
                    read_byte(a);read_byte(b);read_byte(c);read_byte(d);read_byte(e);read_byte(f);
                end
            join
            if({a,b,c,d,e,f} !== {8'h5A,id,expected_zone,expected_status,expected_count,
                                  (8'h5A^id^expected_zone^expected_status^expected_count)}) begin
                $display("Got %02h %02h %02h %02h %02h %02h",a,b,c,d,e,f);
                fail("Response mismatch");
            end
            tests=tests+1;
            #(BIT_NS*2);
        end
    endtask
    initial begin
        #200; key[0]=0; #1000; key[0]=1; #2000;
        if(led!==0) fail("Reset LEDs");
        request(50,0,2,0,0,1,50);
        for(i=1;i<=50;i=i+1) request(i,8,1,0,8,0,i);
        if(led!==10'b0110000000) fail("Zone 8 and OK LEDs");
        if({h5,h4,h3,h2,h1,h0}!==48'h92_C0_C0_80_92_C0) fail("Displays 50 08 50");
        request(50,8,1,0,8,0,50); // Same zone: no double count
        request(2,4,1,0,4,0,1);
        if(led!==10'b0100001000) fail("Zone 4 and OK LEDs");
        if({h5,h4,h3,h2,h1,h0}!==48'hC0_A4_C0_99_C0_F9) fail("Displays 02 04 01");
        request(0,8,5,0,8,2,49); // quiet count
        request(50,0,4,0,8,1,49); // quiet query
        if({h5,h4,h3,h2,h1,h0}!==48'hC0_A4_C0_99_C0_F9) fail("Quiet commands disturbed displays");
        request(2,9,1,0,0,8'hE2,0);
        if(led!==10'b1000001000) fail("Error LED and previous zone");
        request(51,0,2,0,0,8'hE1,0);
        request(0,0,2,0,0,8'hE1,0);
        request(2,0,99,0,0,8'hE3,0);
        request(2,8,1,1,0,8'hE4,0);
        request(2,0,2,0,4,1,1); // errors must not change inventory
        request(0,8,3,0,8,2,49);
        // Partial request must expire after 20 ms.
        send_byte(8'hA5);send_byte(2); #21000000;
        request(2,0,2,0,4,1,1);
        key[0]=0; #1000;key[0]=1;#2000;
        request(0,0,3,0,0,2,50);
        request(50,0,2,0,0,1,50);
        request(0,8,3,0,8,2,0);
        $display("PASS: %0d UART requests plus display/reset tests",tests);$finish;
    end
    initial begin #200000000; fail("Global timeout"); end
endmodule
