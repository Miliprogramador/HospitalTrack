`timescale 1ns/1ps
// Prueba del CORE V2 real. No sintetizar ni agregar al proyecto Quartus.
// Se inyectan bytes como los entregaria uart_rx; no se simula el cable UART.
module tb_hospitaltrack_memoria;
    reg clk = 0;
    always #10 clk = ~clk; // 50 MHz
    reg rst_n = 0;
    reg [7:0] rx_data = 0;
    reg rx_valid = 0;
    wire [47:0] response_frame;
    wire response_valid;
    wire [7:0] display_id, display_zone, display_count;
    wire display_ok, display_error;

    hospitaltrack_core dut (
        .clk(clk), .rst_n(rst_n), .rx_data(rx_data), .rx_valid(rx_valid),
        .response_frame(response_frame), .response_valid(response_valid),
        .display_id(display_id), .display_zone(display_zone),
        .display_count(display_count), .display_ok(display_ok),
        .display_error(display_error)
    );

    // Sondas de simulacion: observan la memoria REAL de dut, sin modificarla.
    wire [3:0] mem_equipo02 = dut.inventory[1];
    wire [3:0] mem_equipo50 = dut.inventory[49];
    wire [1:0] core_state = dut.state; // 0 RECEIVE, 1 SCAN, 2 REPLY
    wire [2:0] rx_index = dut.rx_index;
    wire [7:0] asset_id = dut.asset_id;
    wire [7:0] requested_zone = dut.requested_zone;
    wire [7:0] command = dut.command;
    wire [7:0] next_status = dut.next_status;
    wire commit = rst_n && core_state == 0 && rx_valid && rx_index == 4;
    // Estas sondas reproducen la condicion de escritura/consulta del CORE.
    // No son puertos fisicos ni senales adicionales sintetizadas.
    wire mem_we = commit && !next_status[7] && dut.is_move;
    wire mem_re = commit && !next_status[7] && dut.is_query;
    wire [5:0] mem_addr = (asset_id >= 1 && asset_id <= 50) ? asset_id-1 : 6'd0;
    wire [3:0] mem_wdata = requested_zone[3:0];
    wire [3:0] mem_rdata = (asset_id >= 1 && asset_id <= 50) ? dut.inventory[mem_addr] : 4'd0;
    wire scan_active = core_state == 1;
    wire [5:0] scan_index = dut.scan_index;
    wire [7:0] count = dut.count;
    wire [7:0] resp_id = response_frame[39:32];
    wire [7:0] resp_zone = response_frame[31:24];
    wire [7:0] resp_status = response_frame[23:16];
    wire [7:0] resp_count = response_frame[15:8];
    reg [3:0] phase = 0;
    integer checks = 0;
    integer writes = 0;
    integer reads = 0;
    always @(posedge clk) begin
        if (mem_we) writes = writes + 1;
        if (mem_re) reads = reads + 1;
    end

    task fail;
        input [8*120-1:0] message;
        begin
            $display("FAIL fase %0d: %0s, t=%0t", phase, message, $time);
            $finish;
        end
    endtask

    task send_byte;
        input [7:0] b;
        begin
            @(negedge clk); rx_data = b; rx_valid = 1;
            @(negedge clk); rx_valid = 0;
        end
    endtask

    task request;
        input [7:0] id, zone, cmd, corrupt, exp_zone, exp_status, exp_count;
        integer wait_cycles;
        reg [47:0] expected;
        begin
            expected = {8'h5A, id, exp_zone, exp_status, exp_count,
                        (8'h5A ^ id ^ exp_zone ^ exp_status ^ exp_count)};
            send_byte(8'hA5); send_byte(id); send_byte(zone); send_byte(cmd);
            send_byte(8'hA5 ^ id ^ zone ^ cmd ^ corrupt);
            wait_cycles = 0;
            while (response_valid !== 1'b1 && wait_cycles < 100) begin
                @(negedge clk); wait_cycles = wait_cycles + 1;
            end
            if (response_valid !== 1'b1) fail("Timeout de respuesta");
            if (response_frame !== expected) begin
                $display("Esperado %012h, recibido %012h", expected, response_frame);
                fail("Respuesta incorrecta");
            end
            $display("PASS fase %0d: ID=%0d zona=%0d status=%02h cantidad=%0d", phase, resp_id, resp_zone, resp_status, resp_count);
            checks = checks + 1;
            repeat (10) @(negedge clk);
        end
    endtask

    task check_memory;
        input [3:0] zone02, zone50;
        integer i;
        reg [3:0] expected_zone;
        begin
            for (i=0; i<50; i=i+1) begin
                expected_zone = (i==1) ? zone02 : (i==49) ? zone50 : 4'd0;
                if (dut.inventory[i] !== expected_zone) begin
                    $display("Equipo %0d esperado=%0d recibido=%0d", i+1, expected_zone, dut.inventory[i]);
                    fail("Contenido de memoria incorrecto");
                end
            end
        end
    endtask

    initial begin
        repeat (4) @(negedge clk);
        check_memory(0,0);
        rst_n = 1;
        repeat (4) @(negedge clk);
        phase = 1; request(2,4,1,0,4,0,1); check_memory(4,0);
        phase = 2; request(50,4,1,0,4,0,2); check_memory(4,4);
        phase = 3; request(2,0,2,0,4,1,2); check_memory(4,4);
        phase = 4; request(2,8,1,0,8,0,1); check_memory(8,4);
        phase = 5; request(50,0,2,0,4,1,1); check_memory(8,4);
        phase = 6; request(50,8,1,1,0,8'hE4,0); check_memory(8,4);
        phase = 7; request(50,0,2,0,4,1,1); check_memory(8,4);
        phase = 8; request(0,4,3,0,4,2,1); check_memory(8,4);
        phase = 9; rst_n = 0; repeat (4) @(negedge clk);
        check_memory(0,0); rst_n = 1; repeat (4) @(negedge clk);
        phase = 10; request(2,0,2,0,0,1,50); check_memory(0,0);
        if (writes != 3 || reads != 4 || checks != 9) fail("Numero de operaciones incorrecto");
        phase = 11;
        $display("ALL MEMORY CHECKS PASSED: %0d respuestas, %0d escrituras, %0d consultas", checks, writes, reads);
        repeat (10) @(negedge clk);
        $finish;
    end
    initial begin
        #25000; fail("Timeout global");
    end
`ifdef DUMP_VCD
    initial begin
        $dumpfile("hospitaltrack_memoria.vcd");
        $dumpvars(0,tb_hospitaltrack_memoria);
    end
`endif
endmodule
