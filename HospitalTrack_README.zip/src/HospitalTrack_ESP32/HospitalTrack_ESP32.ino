#include <Arduino.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

constexpr uint8_t MOVE=1, QUERY=2, COUNT=3, QUIET_QUERY=4, QUIET_COUNT=5;
constexpr uint8_t NUM_ASSETS=50, NUM_ZONES=8;
constexpr int LINK_RX_GPIO=16, LINK_TX_GPIO=17;
constexpr unsigned long BAUD=115200;
constexpr unsigned long RESPONSE_TIMEOUT=700;
HardwareSerial FpgaSerial(2);
const char * const ASSETS[] = {
    "ID reservado",
    "Desfibrilador",
    "Monitor cardiaco",
    "Bomba de infusion",
    "Silla de ruedas",
    "Ventilador mecanico",
    "Oximetro de pulso",
    "Electrocardiografo",
    "Monitor multiparametro",
    "Aspirador de secreciones",
    "Monitor de presion arterial",
    "Bisturi electrico",
    "Maquina de anestesia",
    "Lampara quirurgica",
    "Mesa quirurgica",
    "Instrumental de laparoscopia",
    "Pinzas quirurgicas",
    "Separador quirurgico",
    "Sierra quirurgica",
    "Microscopio quirurgico",
    "Equipo de sutura",
    "Ultrasonido portatil",
    "Rayos X portatil",
    "Glucometro",
    "Termometro digital",
    "Estetoscopio",
    "Otoscopio",
    "Oftalmoscopio",
    "Espirometro",
    "Analizador de sangre",
    "Microscopio de laboratorio",
    "Nebulizador",
    "Concentrador de oxigeno",
    "Bomba de jeringa",
    "Equipo de hemodialisis",
    "Incubadora neonatal",
    "Lampara de fototerapia",
    "Equipo de fisioterapia",
    "Electroestimulador",
    "Compresor medico",
    "Equipo de terapia respiratoria",
    "Camilla de traslado",
    "Cama hospitalaria",
    "Tanque de oxigeno portatil",
    "Carro de paro",
    "Carro de curaciones",
    "Andadera",
    "Grua de traslado",
    "Tabla espinal",
    "Collarin cervical",
    "Bolsa de reanimacion manual"
};
const char * const ZONES[] = {
    "Sin registrar",
    "Almacen",
    "Urgencias",
    "Quirofano",
    "Cuidados intensivos (UCI)",
    "Hospitalizacion",
    "Imagenologia",
    "Laboratorio",
    "Consulta externa"
};

struct Reply { uint8_t id, zone, status, count; };
// Declaraciones explicitas para el preprocesador de Arduino.
bool transact(uint8_t id, uint8_t zone, uint8_t cmd, Reply &r);
bool ask(uint8_t id, uint8_t zone, uint8_t cmd, Reply &r);
void showAssetResult(const Reply &r);
void showZones(bool includeZero=false);

// Recibe una linea completa; descarta CR y rechaza entradas demasiado largas.
void readLine(char *out, size_t capacity) {
    for (;;) {
        size_t n=0; bool overflow=false;
        for (;;) {
            if (!Serial.available()) { delay(2); continue; }
            int c=Serial.read();
            if (c=='\r') continue;
            if (c=='\n') break;
            if (c==8 || c==127) { if(n) --n; continue; }
            if (n+1<capacity) out[n++]=(char)c; else overflow=true;
        }
        out[n]='\0';
        if (overflow) { Serial.println("Entrada demasiado larga. Intente de nuevo:"); continue; }
        while (n && isspace((unsigned char)out[n-1])) out[--n]='\0';
        size_t first=0; while (isspace((unsigned char)out[first])) ++first;
        if (first) memmove(out,out+first,strlen(out+first)+1);
        return;
    }
}
bool isChoice(const char *s, char c) {
    return s[0] && !s[1] && toupper((unsigned char)s[0])==c;
}
bool numberIn(const char *s, int lo, int hi, int &value) {
    if (!*s) return false;
    for (const char *p=s; *p; ++p) if (!isdigit((unsigned char)*p)) return false;
    long v=strtol(s,nullptr,10);
    if (v<lo || v>hi) return false;
    value=(int)v; return true;
}
int promptNumber(const char *prompt, int lo, int hi) {
    char line[96]; int v;
    for (;;) {
        Serial.println(prompt); readLine(line,sizeof(line));
        if (isChoice(line,'M')) return -1;
        if (numberIn(line,lo,hi,v)) return v;
        Serial.printf("Numero invalido. Use %02d a %02d, o M para volver.\n",lo,hi);
    }
}
void header(const char *title) {
    Serial.println("\n============================================================");
    Serial.println(title);
    Serial.println("============================================================");
}
void pauseMenu() {
    char line[96]; Serial.println("Presione ENTER para volver al menu."); readLine(line,sizeof(line));
}
const char *statusName(uint8_t s) {
    switch(s) {
        case 0x00: return "Movimiento exitoso";
        case 0x01: return "Consulta exitosa";
        case 0x02: return "Conteo exitoso";
        case 0xE1: return "ID de equipo invalido";
        case 0xE2: return "Zona invalida";
        case 0xE3: return "Comando invalido";
        case 0xE4: return "Checksum incorrecto";
        default: return "Estado desconocido";
    }
}
bool transact(uint8_t id, uint8_t zone, uint8_t cmd, Reply &r) {
    uint8_t request[5]={0xA5,id,zone,cmd,(uint8_t)(0xA5^id^zone^cmd)};
    while (FpgaSerial.available()) FpgaSerial.read();
    FpgaSerial.write(request,sizeof(request));
    uint8_t frame[6]; size_t n=0;
    unsigned long start=millis();
    while ((unsigned long)(millis()-start)<RESPONSE_TIMEOUT) {
        if (!FpgaSerial.available()) { delay(1); continue; }
        int raw=FpgaSerial.read(); if(raw<0) continue;
        uint8_t b=(uint8_t)raw;
        if (n==0 && b!=0x5A) continue;
        frame[n++]=b;
        if (n!=sizeof(frame)) continue;
        n=0;
        if ((uint8_t)(frame[0]^frame[1]^frame[2]^frame[3]^frame[4])!=frame[5]) continue;
        if (frame[1]!=id || frame[2]>NUM_ZONES || frame[4]>NUM_ASSETS) continue;
        uint8_t expected=cmd==MOVE?0:(cmd==QUERY||cmd==QUIET_QUERY?1:2);
        if (frame[3]!=expected && (frame[3]<0xE1 || frame[3]>0xE4)) continue;
        if (frame[3]==expected && (cmd==MOVE||cmd==COUNT||cmd==QUIET_COUNT) && frame[2]!=zone) continue;
        r.id=frame[1]; r.zone=frame[2]; r.status=frame[3]; r.count=frame[4]; return true;
    }
    return false;
}
bool ask(uint8_t id, uint8_t zone, uint8_t cmd, Reply &r) {
    if (!transact(id,zone,cmd,r)) {
        Serial.println("ERROR DE COMUNICACION: sin respuesta valida de la FPGA.");
        Serial.println("Revise alimentacion, GND, TX/RX y que ambas placas tengan V2.");
        if(cmd==MOVE) Serial.println("El traslado pudo haberse aplicado. Consulte antes de repetir.");
        return false;
    }
    if (r.status>=0xE1) {
        Serial.printf("FPGA RECHAZO [%02X]: %s\n",(unsigned)r.status,statusName(r.status)); return false;
    }
    return true;
}
void showZones(bool includeZero) {
    for (int i=includeZero?0:1;i<=NUM_ZONES;++i) Serial.printf(" [%02d] %s\n",i,ZONES[i]);
}
void showAssetResult(const Reply &r) {
    Serial.printf(" Equipo:   %02d - %s\n",(int)r.id,ASSETS[r.id]);
    Serial.printf(" Zona:     %02d - %s\n",(int)r.zone,ZONES[r.zone]);
    Serial.printf(" Cantidad: %02d %s\n",(int)r.count,r.zone?"equipos en esta zona":"equipos sin registrar");
    Serial.printf(" Estado:   %s [%02X]\n",statusName(r.status),(unsigned)r.status);
}
void locate(int id) {
    Reply r; header("LOCALIZAR EQUIPO");
    if (ask(id,0,QUERY,r)) showAssetResult(r);
}
void moveAsset(int id, int dest) {
    Reply r, previous;
    if (!ask(id,0,QUIET_QUERY,previous)) return;
    if (ask(id,dest,MOVE,r)) {
        header("TRASLADO EXITOSO");
        Serial.printf(" Origen:   %s\n",ZONES[previous.zone]);
        showAssetResult(r);
    }
}
void relocate() {
    header("TRASLADAR EQUIPO | M = regresar");
    int id=promptNumber("ID del equipo (01-50):",1,50); if(id<0) return;
    Reply r; if (!ask(id,0,QUIET_QUERY,r)) return;
    Serial.printf("Equipo %02d: %s\nUbicacion actual: %s\n",id,ASSETS[id],ZONES[r.zone]);
    showZones();
    int dest=promptNumber("Nueva zona (01-08):",1,8); if(dest<0) return;
    char line[96]; Serial.println("Confirmar traslado? S = si, otra tecla = cancelar.");
    readLine(line,sizeof(line)); if(!isChoice(line,'S')) { Serial.println("Traslado cancelado."); return; }
    moveAsset(id,dest);
}
void tableHeading() {
    Serial.printf("%-3s %-32s %s\n","ID","INSTRUMENTO","UBICACION");
    Serial.println("------------------------------------------------------------");
}
void tableRow(int id,uint8_t z) { Serial.printf("%02d  %-32s %s\n",id,ASSETS[id],ZONES[z]); }
bool containsIgnoreCase(const char *s,const char *q) {
    if(!*q) return true;
    for(;*s;++s) {
        const char *a=s,*b=q;
        while(*a && *b && tolower((unsigned char)*a)==tolower((unsigned char)*b)) { ++a;++b; }
        if(!*b) return true;
    }
    return false;
}
void inventoryPages(bool catalog) {
    int page=0; char line[96];
    for (;;) {
        header(catalog?"CATALOGO DE 50 EQUIPOS":"INVENTARIO GENERAL");
        if(!catalog) tableHeading();
        for(int id=page*10+1;id<=page*10+10;++id) {
            if(catalog) Serial.printf(" [%02d] %s\n",id,ASSETS[id]);
            else { Reply r; if(!ask(id,0,QUIET_QUERY,r)) return; tableRow(id,r.zone); }
        }
        Serial.printf("\nPagina %d de 5 | N siguiente | A anterior | B buscar | M menu\n",page+1);
        readLine(line,sizeof(line));
        if(isChoice(line,'M')) return;
        if(isChoice(line,'N')) { if(page<4) ++page; else Serial.println("Ultima pagina."); }
        else if(isChoice(line,'A')) { if(page>0) --page; else Serial.println("Primera pagina."); }
        else if(isChoice(line,'B')) {
            Serial.println("Escriba ID o parte del nombre (sin acentos):"); readLine(line,sizeof(line));
            if(isChoice(line,'M')) return;
            int wanted=0, found=0; bool byId=numberIn(line,1,50,wanted);
            if(!catalog) tableHeading();
            for(int id=1;id<=NUM_ASSETS;++id) if(byId?id==wanted:containsIgnoreCase(ASSETS[id],line)) {
                ++found;
                if(catalog) Serial.printf(" [%02d] %s\n",id,ASSETS[id]);
                else { Reply r; if(!ask(id,0,QUIET_QUERY,r)) return; tableRow(id,r.zone); }
            }
            Serial.printf("%d coincidencias. ENTER para volver a la pagina.\n",found); readLine(line,sizeof(line));
        } else Serial.println("Use N, A, B o M.");
    }
}
void listZone() {
    header("EQUIPOS POR ZONA | M = regresar"); showZones(true);
    int z=promptNumber("Seleccione zona (00-08):",0,8); if(z<0) return;
    Reply r; if(!ask(0,z,COUNT,r)) return;
    Serial.printf("Zona %02d: %s | Total: %02d\n",z,ZONES[z],(int)r.count);
    tableHeading(); int listed=0;
    for(int id=1;id<=NUM_ASSETS;++id) {
        Reply q; if(!ask(id,0,QUIET_QUERY,q)) return;
        if(q.zone==z) { tableRow(id,q.zone); ++listed; }
    }
    if(!listed) Serial.println("No hay instrumentos en esta zona.");
    if(listed!=r.count) Serial.println("El inventario cambio durante la consulta. Vuelva a consultar.");
}
void overview() {
    header("RESUMEN HOSPITALARIO"); int total=0,registered=0;
    for(int z=0;z<=NUM_ZONES;++z) {
        Reply r; if(!ask(0,z,QUIET_COUNT,r)) return;
        Serial.printf("%02d  %-28s %02d\n",z,ZONES[z],(int)r.count);
        total+=r.count; if(z) registered+=r.count;
    }
    Serial.printf("\nRegistrados: %d | Sin ubicar: %d | Capacidad: 50\n",registered,total-registered);
    if(total!=50) Serial.println("Inventario cambio durante la lectura; vuelva a consultar.");
}
void menu() {
    header("HOSPITALTRACK V2 | CONTROL CENTRAL FPGA");
    Serial.println("50 equipos | 8 zonas | DE10-Lite + ESP32");
    Serial.println("\n [1] Localizar un equipo\n [2] Trasladar un equipo\n [3] Inventario completo\n [4] Equipos por zona\n [5] Catalogo de equipos\n [6] Resumen y zonas del hospital\n [7] Ayuda");
    Serial.println("Seleccione una opcion (1-7):");
}
void setup() {
    Serial.begin(BAUD); FpgaSerial.begin(BAUD,SERIAL_8N1,LINK_RX_GPIO,LINK_TX_GPIO);
    delay(300); Serial.println("HospitalTrack V2 listo. Monitor: 115200, Nueva linea.");
}
void loop() {
    char line[96]; menu(); readLine(line,sizeof(line));
    int option;
    if(numberIn(line,1,7,option)) {
        switch(option) {
            case 1: { int id=promptNumber("ID del equipo (01-50) o M:",1,50); if(id<0)return; locate(id); break; }
            case 2: relocate(); break;
            case 3: inventoryPages(false); return;
            case 4: listZone(); break;
            case 5: inventoryPages(true); return;
            case 6: overview(); break;
            case 7: header("AYUDA"); Serial.println("Use los IDs decimales. Consulte el catalogo con 5.\nHEX5-4: equipo; HEX3-2: zona; HEX1-0: cantidad.\nLEDR0-7: zonas 1-8; LEDR8: OK; LEDR9: error FPGA.\nKEY0 borra ubicaciones; al arrancar todos estan en zona 00.\nNo se detectan traslados fisicos automaticamente.\nComandos directos: MOVER 02 03 / CONSULTAR 02."); break;
        }
        pauseMenu(); return;
    }
    // Compatibilidad con los comandos originales. IDs y zonas en decimal.
    int id=0,z=0; char extra;
    if(sscanf(line,"MOVER %d %d %c",&id,&z,&extra)==2 && id>=1 && id<=50 && z>=1 && z<=8) moveAsset(id,z);
    else if(sscanf(line,"CONSULTAR %d %c",&id,&extra)==1 && id>=1 && id<=50) locate(id);
    else { if(*line) Serial.println("Opcion o comando invalido. Use 1 a 7."); return; }
    pauseMenu();
}
